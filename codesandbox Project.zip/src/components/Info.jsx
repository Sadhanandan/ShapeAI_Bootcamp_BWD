import React from "react";

function info(){
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>A basic web React Js BOOTCAMP</p>
    </div>
  );
}

export default info;